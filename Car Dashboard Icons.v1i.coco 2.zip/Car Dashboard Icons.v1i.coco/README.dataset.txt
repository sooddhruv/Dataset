# Car Dashboard Icons > 2022-06-01 11:20am
https://universe.roboflow.com/object-detection/car-dashboard-icons-msfn4

Provided by Roboflow
License: CC BY 4.0

